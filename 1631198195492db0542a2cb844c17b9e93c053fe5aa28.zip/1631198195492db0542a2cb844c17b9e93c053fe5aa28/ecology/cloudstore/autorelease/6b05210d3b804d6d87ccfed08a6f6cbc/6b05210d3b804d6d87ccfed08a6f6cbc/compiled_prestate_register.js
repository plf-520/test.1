"use strict";

var enable = false;
ecodeSDK.overwritePropsFnQueueMapSet('WeaRichText', {
  fn: function fn(newProps) {
    console.log('ckConfig', newProps);
    newProps.ckConfig = {
      forcePasteAsPlainText: true
    };
  },
  order: 1,
  desc: '复写解决富文本的黏贴问题'
});